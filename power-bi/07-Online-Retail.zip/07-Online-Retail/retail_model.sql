/* UK online gift retailer - sales, customer and product model, SQL Server 2019+
   Source: Online Retail II, UCI Machine Learning Repository (Chen, 2019), CC BY 4.0.
   Invoice lines from 1 Dec 2009 to 9 Dec 2011, about 1.07 million rows.

   Before running: open online_retail_II.xlsx, set the InvoiceDate column to the format yyyy-mm-dd hh:mm,
   and save each of the two sheets as CSV UTF-8 (retail_2009_2010.csv and retail_2010_2011.csv).
   Change @Folder to the folder that holds the two files. Run in a database named RetailPortfolio (the SSRS report connects to it).

   Steps: 1 staging, 2 clean lines, 3 remove order-entry errors, 4 product dimension with family and ABC tier,
   5 country and region, 6 customer dimension with RFM segments, 7 facts, 8 checks, 9 views for Power BI and SSRS. */

SET NOCOUNT ON;
IF SCHEMA_ID('stg') IS NULL EXEC('CREATE SCHEMA stg');
IF SCHEMA_ID('rtl') IS NULL EXEC('CREATE SCHEMA rtl');
GO

/* ---------- 1. Staging: raw files, loaded as text */
DROP TABLE IF EXISTS stg.RetailLine;
CREATE TABLE stg.RetailLine (
    Invoice varchar(10), StockCode varchar(20), Description nvarchar(100), Quantity varchar(10),
    InvoiceDate varchar(20), Price varchar(20), CustomerID varchar(10), Country varchar(40));
GO

DECLARE @Folder nvarchar(260) = N'C:\Users\srush\Downloads\Certificates\Portfolio\Data\07-Retail\';
DECLARE @sql nvarchar(max) =
    N'BULK INSERT stg.RetailLine FROM ''' + @Folder + N'retail_2009_2010.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, CODEPAGE = ''65001'');' +
    N'BULK INSERT stg.RetailLine FROM ''' + @Folder + N'retail_2010_2011.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, CODEPAGE = ''65001'');';
EXEC sp_executesql @sql;
GO

/* ---------- 2. Clean lines
   Kept: product lines only (stock codes start with a digit; postage, fees, manual adjustments and gift vouchers are dropped)
   and a price above zero. Cancellations (invoice starts with C) and negative quantities are kept as returns. */
DROP TABLE IF EXISTS rtl.FactCustomerMonth, rtl.FactSalesMonth, rtl.FactOrdersMonth, rtl.DimCustomer, rtl.DimProduct,
                     rtl.DimCountry, rtl.FamilyKeyword, rtl.Line;

CREATE TABLE rtl.Line (
    LineID         int            NOT NULL PRIMARY KEY,
    Invoice        varchar(10)    NOT NULL,
    StockCode      varchar(20)    NOT NULL,
    Description    nvarchar(100)  NOT NULL,
    Quantity       int            NOT NULL,
    InvoiceDate    datetime2(0)   NOT NULL,
    MonthStart     date           NOT NULL,
    Price          decimal(10,2)  NOT NULL,
    CustomerID     int            NULL,      -- blank for guest checkouts
    Country        varchar(40)    NOT NULL,
    IsReturn       bit            NOT NULL,
    Revenue        decimal(12,2)  NOT NULL,  -- GBP, negative for returns
    ExcludeReason  varchar(40)    NULL
);

INSERT rtl.Line (LineID, Invoice, StockCode, Description, Quantity, InvoiceDate, MonthStart, Price, CustomerID, Country, IsReturn, Revenue, ExcludeReason)
SELECT ROW_NUMBER() OVER (ORDER BY x.InvoiceDate, s.Invoice, s.StockCode),
       s.Invoice, x.StockCode, UPPER(LTRIM(RTRIM(COALESCE(s.Description, N'')))), x.Quantity, x.InvoiceDate,
       DATEFROMPARTS(YEAR(x.InvoiceDate), MONTH(x.InvoiceDate), 1), x.Price,
       TRY_CAST(TRY_CAST(NULLIF(s.CustomerID, '') AS float) AS int), s.Country,
       CASE WHEN s.Invoice LIKE 'C%' OR x.Quantity < 0 THEN 1 ELSE 0 END,
       CAST(x.Quantity * x.Price AS decimal(12,2)), NULL
FROM stg.RetailLine s
CROSS APPLY (SELECT UPPER(LTRIM(RTRIM(s.StockCode))) AS StockCode, CAST(s.Quantity AS int) AS Quantity,
                    CAST(s.Price AS decimal(10,2)) AS Price, CAST(s.InvoiceDate AS datetime2(0)) AS InvoiceDate) x
WHERE LEFT(x.StockCode, 1) BETWEEN '0' AND '9'
  AND x.Price > 0;
GO

/* ---------- 3. Order-entry errors
   Very large lines (GBP 5,000 or more) cancelled by the same customer within a day, for the same item and quantity
   (for example 80,995 paper craft kits), and one-off sales of GBP 30,000 or more that were credited by hand.
   Both sides are flagged so they inflate neither sales nor returns. */
WITH big AS (SELECT * FROM rtl.Line WHERE ABS(Revenue) >= 5000),
pairs AS (
    SELECT r.LineID AS ReturnLine, s.LineID AS SaleLine,
           ROW_NUMBER() OVER (PARTITION BY r.LineID ORDER BY s.LineID) AS rn
    FROM big r
    JOIN big s
      ON s.IsReturn = 0 AND r.IsReturn = 1
     AND s.CustomerID = r.CustomerID AND s.StockCode = r.StockCode AND s.Quantity = -r.Quantity
     AND ABS(DATEDIFF(minute, s.InvoiceDate, r.InvoiceDate)) <= 1440)
UPDATE rtl.Line SET ExcludeReason = 'Order-entry error'
WHERE LineID IN (SELECT ReturnLine FROM pairs WHERE rn = 1 UNION SELECT SaleLine FROM pairs WHERE rn = 1);

UPDATE rtl.Line SET ExcludeReason = 'Order-entry error'
WHERE IsReturn = 0 AND Revenue >= 30000;
GO

/* ---------- 4. Products: description, family and ABC tier
   Description = the most common description on sales lines. Family = first keyword match in priority order. */
CREATE TABLE rtl.FamilyKeyword (Priority tinyint NOT NULL, Family varchar(30) NOT NULL, Keyword varchar(20) NOT NULL);
INSERT rtl.FamilyKeyword (Priority, Family, Keyword) VALUES
 (1,'Christmas','CHRISTMAS'),(1,'Christmas','XMAS'),(1,'Christmas','ADVENT'),(1,'Christmas','SNOWFLAKE'),(1,'Christmas','REINDEER'),(1,'Christmas','SANTA'),
 (2,'Bags','BAG'),(2,'Bags','TOTE'),(2,'Bags','SHOPPER'),
 (3,'Candles and lights','CANDLE'),(3,'Candles and lights','T-LIGHT'),(3,'Candles and lights','LANTERN'),(3,'Candles and lights','LIGHT'),
 (3,'Candles and lights','LAMP'),(3,'Candles and lights','HOLDER'),
 (4,'Kitchen and dining','MUG'),(4,'Kitchen and dining','CUP'),(4,'Kitchen and dining','PLATE'),(4,'Kitchen and dining','BOWL'),
 (4,'Kitchen and dining','JAR'),(4,'Kitchen and dining',' TIN'),(4,'Kitchen and dining','LUNCH'),(4,'Kitchen and dining','CAKE'),
 (4,'Kitchen and dining','BAKING'),(4,'Kitchen and dining','TEA'),(4,'Kitchen and dining','SPOON'),(4,'Kitchen and dining','APRON'),
 (4,'Kitchen and dining','NAPKIN'),(4,'Kitchen and dining','BOTTLE'),(4,'Kitchen and dining','CUTLERY'),(4,'Kitchen and dining','KITCHEN'),
 (4,'Kitchen and dining','JUG'),(4,'Kitchen and dining','BREAD'),(4,'Kitchen and dining','JAM '),(4,'Kitchen and dining','MOULD'),
 (4,'Kitchen and dining','COOKIE'),(4,'Kitchen and dining','PANTRY'),
 (5,'Home decor','HEART'),(5,'Home decor',' SIGN'),(5,'Home decor','FRAME'),(5,'Home decor','CLOCK'),(5,'Home decor','CUSHION'),
 (5,'Home decor','DOORMAT'),(5,'Home decor','HANGING'),(5,'Home decor','WREATH'),(5,'Home decor','ORNAMENT'),(5,'Home decor','DECORATION'),
 (5,'Home decor','VINTAGE'),(5,'Home decor','BIRD'),(5,'Home decor','HOOK'),(5,'Home decor','BOARD'),(5,'Home decor','CABINET'),
 (5,'Home decor','RACK'),(5,'Home decor','THROW'),
 (6,'Stationery and cards','CARD'),(6,'Stationery and cards','WRAP'),(6,'Stationery and cards','PAPER'),(6,'Stationery and cards','NOTEBOOK'),
 (6,'Stationery and cards','PENCIL'),(6,'Stationery and cards','STICKER'),(6,'Stationery and cards','TAPE'),(6,'Stationery and cards','CALENDAR'),
 (6,'Stationery and cards','BOOK'),
 (7,'Storage','BOX'),(7,'Storage','BASKET'),(7,'Storage','CASE'),(7,'Storage','DRAWER'),(7,'Storage','STORAGE'),(7,'Storage','CRATE'),
 (8,'Toys and party','TOY'),(8,'Toys and party','PARTY'),(8,'Toys and party','BUNTING'),(8,'Toys and party','BALLOON'),(8,'Toys and party','GAME'),
 (8,'Toys and party','PUZZLE'),(8,'Toys and party','DOLL'),(8,'Toys and party','SPACEBOY'),(8,'Toys and party','BLOCK'),
 (8,'Toys and party','CRAFT'),(8,'Toys and party','GLIDER'),(8,'Toys and party','COLOURING'),(8,'Toys and party','CLAY'),(8,'Toys and party','SKITTLE'),
 (8,'Toys and party','SKIPPING'),(8,'Toys and party','JIGSAW'),
 (9,'Accessories','UMBRELLA'),(9,'Accessories','PARASOL'),(9,'Accessories','WARMER'),(9,'Accessories','FAN'),(9,'Accessories','PURSE'),
 (9,'Accessories','NECKLACE'),(9,'Accessories','BRACELET'),(9,'Accessories','EARRING'),(9,'Accessories','HAIR'),(9,'Accessories','RIBBON'),
 (9,'Accessories','SEWING'),
 (10,'Garden','GARDEN'),(10,'Garden','PLANT'),(10,'Garden','WATERING'),(10,'Garden',' POT');

CREATE TABLE rtl.DimProduct (
    StockCode        varchar(20)    NOT NULL PRIMARY KEY,
    Description      nvarchar(100)  NOT NULL,
    Family           varchar(30)    NOT NULL,
    Gross            decimal(14,2)  NOT NULL,
    Returns          decimal(14,2)  NOT NULL,
    Units            int            NOT NULL,
    Customers        int            NOT NULL,
    SalesRank        int            NOT NULL,
    CumulativeShare  decimal(9,6)   NOT NULL,
    ABCTier          char(1)        NOT NULL CHECK (ABCTier IN ('A', 'B', 'C'))
);

WITH sales AS (SELECT * FROM rtl.Line WHERE ExcludeReason IS NULL),
desc_count AS (
    SELECT StockCode, Description, COUNT(*) AS n,
           ROW_NUMBER() OVER (PARTITION BY StockCode ORDER BY COUNT(*) DESC, Description) AS rn
    FROM sales WHERE IsReturn = 0 GROUP BY StockCode, Description),
fam AS (
    SELECT d.StockCode, k.Family, ROW_NUMBER() OVER (PARTITION BY d.StockCode ORDER BY k.Priority, k.Keyword) AS rn
    FROM desc_count d JOIN rtl.FamilyKeyword k ON d.Description LIKE CONCAT('%', k.Keyword, '%')
    WHERE d.rn = 1),
totals AS (
    SELECT StockCode,
           SUM(CASE WHEN IsReturn = 0 THEN Revenue ELSE 0 END) AS Gross,
           -SUM(CASE WHEN IsReturn = 1 THEN Revenue ELSE 0 END) AS Returns,
           SUM(CASE WHEN IsReturn = 0 THEN Quantity ELSE 0 END) AS Units,
           COUNT(DISTINCT CASE WHEN IsReturn = 0 THEN CustomerID END) AS Customers
    FROM sales GROUP BY StockCode),
ranked AS (
    SELECT t.*, d.Description, COALESCE(f.Family, 'Other') AS Family,
           ROW_NUMBER() OVER (ORDER BY t.Gross DESC, t.StockCode) AS SalesRank,
           SUM(t.Gross) OVER (ORDER BY t.Gross DESC, t.StockCode ROWS UNBOUNDED PRECEDING) / SUM(t.Gross) OVER () AS CumulativeShare
    FROM totals t
    JOIN desc_count d ON d.StockCode = t.StockCode AND d.rn = 1     -- products that were only ever returned drop out here
    LEFT JOIN fam f ON f.StockCode = t.StockCode AND f.rn = 1)
INSERT rtl.DimProduct (StockCode, Description, Family, Gross, Returns, Units, Customers, SalesRank, CumulativeShare, ABCTier)
SELECT StockCode, Description, Family, Gross, Returns, Units, Customers, SalesRank, CumulativeShare,
       CASE WHEN CumulativeShare <= 0.80 THEN 'A' WHEN CumulativeShare <= 0.95 THEN 'B' ELSE 'C' END
FROM ranked;
GO

/* ---------- 5. Countries and regions (the Power BI Region manager role filters on RegionManagerEmail) */
CREATE TABLE rtl.DimCountry (
    Country             varchar(40)  NOT NULL PRIMARY KEY,
    Region              varchar(20)  NOT NULL CHECK (Region IN ('United Kingdom', 'Europe', 'Rest of world')),
    RegionManagerEmail  varchar(120) NOT NULL
);
INSERT rtl.DimCountry (Country, Region, RegionManagerEmail)
SELECT c.Country, r.Region, CONCAT('manager.', LOWER(REPLACE(r.Region, ' ', '-')), '@giftco.example')
FROM (SELECT DISTINCT Country FROM rtl.Line) c
CROSS APPLY (SELECT CASE
    WHEN c.Country = 'United Kingdom' THEN 'United Kingdom'
    WHEN c.Country IN ('Austria','Belgium','Channel Islands','Cyprus','Czech Republic','Denmark','EIRE','European Community','Finland',
                       'France','Germany','Greece','Iceland','Italy','Lithuania','Malta','Netherlands','Norway','Poland','Portugal',
                       'Spain','Sweden','Switzerland') THEN 'Europe'
    ELSE 'Rest of world' END AS Region) r;
GO

/* ---------- 6. Customers with RFM segments, as at 10 Dec 2011 (the day after the last invoice)
   R, F and M are quintiles (1 to 5) of days since last purchase, number of orders and gross spend. */
CREATE TABLE rtl.DimCustomer (
    CustomerID     int            NOT NULL PRIMARY KEY,
    Country        varchar(40)    NOT NULL REFERENCES rtl.DimCountry (Country),
    FirstPurchase  date           NOT NULL,
    LastPurchase   date           NOT NULL,
    CohortMonth    date           NOT NULL,
    Orders         int            NOT NULL,
    Revenue        decimal(14,2)  NOT NULL,
    RecencyDays    int            NOT NULL,
    R tinyint NOT NULL, F tinyint NOT NULL, M tinyint NOT NULL,
    Segment        varchar(30)    NOT NULL
);

DECLARE @Snapshot date = '2011-12-10';
WITH sales AS (SELECT * FROM rtl.Line WHERE ExcludeReason IS NULL AND IsReturn = 0 AND CustomerID IS NOT NULL),
home AS (
    SELECT CustomerID, Country, ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY COUNT(*) DESC, Country) AS rn
    FROM sales GROUP BY CustomerID, Country),
agg AS (
    SELECT CustomerID, MIN(InvoiceDate) AS FirstPurchase, MAX(InvoiceDate) AS LastPurchase,
           COUNT(DISTINCT Invoice) AS Orders, SUM(Revenue) AS Revenue
    FROM sales GROUP BY CustomerID),
scored AS (
    SELECT a.*, h.Country, DATEDIFF(day, CAST(a.LastPurchase AS date), @Snapshot) AS RecencyDays,
           NTILE(5) OVER (ORDER BY a.LastPurchase, a.CustomerID) AS R,      -- most recent buyers score 5
           NTILE(5) OVER (ORDER BY a.Orders, a.CustomerID) AS F,
           NTILE(5) OVER (ORDER BY a.Revenue, a.CustomerID) AS M
    FROM agg a JOIN home h ON h.CustomerID = a.CustomerID AND h.rn = 1)
INSERT rtl.DimCustomer (CustomerID, Country, FirstPurchase, LastPurchase, CohortMonth, Orders, Revenue, RecencyDays, R, F, M, Segment)
SELECT CustomerID, Country, CAST(FirstPurchase AS date), CAST(LastPurchase AS date),
       DATEFROMPARTS(YEAR(FirstPurchase), MONTH(FirstPurchase), 1), Orders, Revenue, RecencyDays, R, F, M,
       CASE WHEN R >= 4 AND (F + M) / 2.0 >= 4   THEN 'Champions'
            WHEN R >= 3 AND (F + M) / 2.0 >= 3   THEN 'Loyal'
            WHEN R >= 4 AND (F + M) / 2.0 < 2.5  THEN 'New or promising'
            WHEN R <= 2 AND (F + M) / 2.0 >= 4   THEN 'At risk, high value'
            WHEN R <= 2 AND (F + M) / 2.0 >= 2.5 THEN 'At risk'
            WHEN R = 1                           THEN 'Lost'
            ELSE 'Needs attention' END
FROM scored;
GO

/* ---------- 7. Facts at month grain */
-- sales and returns by month, product family and country (all lines, including guest checkouts)
CREATE TABLE rtl.FactSalesMonth (
    MonthStart date NOT NULL, Family varchar(30) NOT NULL, Country varchar(40) NOT NULL REFERENCES rtl.DimCountry (Country),
    Gross decimal(14,2) NOT NULL, Returns decimal(14,2) NOT NULL, Units int NOT NULL,
    CONSTRAINT PK_FactSalesMonth PRIMARY KEY (MonthStart, Family, Country));
INSERT rtl.FactSalesMonth (MonthStart, Family, Country, Gross, Returns, Units)
SELECT l.MonthStart, COALESCE(p.Family, 'Other'), l.Country,
       SUM(CASE WHEN l.IsReturn = 0 THEN l.Revenue ELSE 0 END), -SUM(CASE WHEN l.IsReturn = 1 THEN l.Revenue ELSE 0 END),
       SUM(CASE WHEN l.IsReturn = 0 THEN l.Quantity ELSE 0 END)
FROM rtl.Line l LEFT JOIN rtl.DimProduct p ON p.StockCode = l.StockCode
WHERE l.ExcludeReason IS NULL
GROUP BY l.MonthStart, COALESCE(p.Family, 'Other'), l.Country;

-- orders (distinct sales invoices) by month and country
CREATE TABLE rtl.FactOrdersMonth (
    MonthStart date NOT NULL, Country varchar(40) NOT NULL REFERENCES rtl.DimCountry (Country), Orders int NOT NULL,
    CONSTRAINT PK_FactOrdersMonth PRIMARY KEY (MonthStart, Country));
INSERT rtl.FactOrdersMonth (MonthStart, Country, Orders)
SELECT MonthStart, Country, COUNT(DISTINCT Invoice) FROM rtl.Line
WHERE ExcludeReason IS NULL AND IsReturn = 0 GROUP BY MonthStart, Country;

-- each identified customer's spend and orders by month
CREATE TABLE rtl.FactCustomerMonth (
    CustomerID int NOT NULL REFERENCES rtl.DimCustomer (CustomerID), MonthStart date NOT NULL,
    Revenue decimal(14,2) NOT NULL, Orders int NOT NULL,
    CONSTRAINT PK_FactCustomerMonth PRIMARY KEY (CustomerID, MonthStart));
INSERT rtl.FactCustomerMonth (CustomerID, MonthStart, Revenue, Orders)
SELECT CustomerID, MonthStart, SUM(Revenue), COUNT(DISTINCT Invoice) FROM rtl.Line
WHERE ExcludeReason IS NULL AND IsReturn = 0 AND CustomerID IS NOT NULL GROUP BY CustomerID, MonthStart;
GO

/* ---------- 8. Checks: each should return 0 rows */
-- facts reconcile to the clean lines
SELECT 'sales' AS Fact WHERE (SELECT SUM(Gross) FROM rtl.FactSalesMonth)
    <> (SELECT SUM(Revenue) FROM rtl.Line WHERE ExcludeReason IS NULL AND IsReturn = 0);
SELECT 'customers' AS Fact WHERE (SELECT SUM(Revenue) FROM rtl.FactCustomerMonth) <> (SELECT SUM(Revenue) FROM rtl.DimCustomer);
-- every flagged return has a flagged sale of the same item, quantity and customer
SELECT r.LineID FROM rtl.Line r
WHERE r.ExcludeReason IS NOT NULL AND r.IsReturn = 1
  AND NOT EXISTS (SELECT 1 FROM rtl.Line s WHERE s.ExcludeReason IS NOT NULL AND s.IsReturn = 0
                  AND s.CustomerID = r.CustomerID AND s.StockCode = r.StockCode AND s.Quantity = -r.Quantity);
-- ABC tiers are in sales order
SELECT StockCode FROM rtl.DimProduct a
WHERE EXISTS (SELECT 1 FROM rtl.DimProduct b WHERE b.SalesRank > a.SalesRank AND b.ABCTier < a.ABCTier);
-- each customer's cohort month is the month of their first purchase in the fact
SELECT c.CustomerID FROM rtl.DimCustomer c
WHERE c.CohortMonth <> (SELECT MIN(f.MonthStart) FROM rtl.FactCustomerMonth f WHERE f.CustomerID = c.CustomerID);
GO

/* ---------- 9. Views the Power BI model and the SSRS win-back report read */
CREATE OR ALTER VIEW rtl.vCountry AS
SELECT Country, Region, RegionManagerEmail AS [Region Manager Email] FROM rtl.DimCountry;
GO
CREATE OR ALTER VIEW rtl.vSalesMonth AS
SELECT MonthStart AS [Month], Family, Country, Gross, Returns, Units FROM rtl.FactSalesMonth;
GO
CREATE OR ALTER VIEW rtl.vOrdersMonth AS
SELECT MonthStart AS [Month], Country, Orders FROM rtl.FactOrdersMonth;
GO
CREATE OR ALTER VIEW rtl.vCustomer AS
SELECT CustomerID AS [Customer ID], Country, Segment, R AS [R Score], F AS [F Score], M AS [M Score], CohortMonth AS [Cohort],
       FirstPurchase AS [First Purchase], LastPurchase AS [Last Purchase], RecencyDays AS [Days Since Last Order],
       Orders AS [Lifetime Orders], Revenue AS [Lifetime Spend]
FROM rtl.DimCustomer;
GO
CREATE OR ALTER VIEW rtl.vCustomerMonth AS
SELECT f.CustomerID AS [Customer ID], f.MonthStart AS [Month], f.Revenue, f.Orders,
       DATEDIFF(month, c.CohortMonth, f.MonthStart) AS [Months Since First Order]
FROM rtl.FactCustomerMonth f JOIN rtl.DimCustomer c ON c.CustomerID = f.CustomerID;
GO
CREATE OR ALTER VIEW rtl.vProduct AS
SELECT StockCode AS [Stock Code], Description, Family, Gross, Returns, Units, Customers, SalesRank AS [Sales Rank],
       CumulativeShare AS [Cumulative Share], ABCTier AS [ABC Tier]
FROM rtl.DimProduct;
GO

/* Cohort retention, used to reconcile the report's heatmap */
CREATE OR ALTER VIEW rtl.vCohortRetention AS
SELECT c.CohortMonth AS [Cohort],
       DATEDIFF(month, c.CohortMonth, f.MonthStart) AS [Months Since First Order],
       COUNT(DISTINCT f.CustomerID) AS [Active Customers],
       MAX(s.CohortSize) AS [Cohort Size]
FROM rtl.FactCustomerMonth f
JOIN rtl.DimCustomer c ON c.CustomerID = f.CustomerID
JOIN (SELECT CohortMonth, COUNT(*) AS CohortSize FROM rtl.DimCustomer GROUP BY CohortMonth) s ON s.CohortMonth = c.CohortMonth
WHERE c.CohortMonth < '2011-12-01' AND DATEDIFF(month, c.CohortMonth, f.MonthStart) <= 12
GROUP BY c.CohortMonth, DATEDIFF(month, c.CohortMonth, f.MonthStart);
GO

/* Win-back list: customers who used to buy often or spend a lot and have gone quiet */
CREATE OR ALTER VIEW rtl.vWinBack AS
SELECT c.CustomerID AS [Customer ID], c.Country, k.Region, c.Segment, c.LastPurchase AS [Last Purchase],
       c.RecencyDays AS [Days Since Last Order], c.Orders, c.Revenue AS [Lifetime Spend],
       CAST(c.Revenue / c.Orders AS decimal(12,2)) AS [Average Order],
       fav.Family AS [Favourite Family]
FROM rtl.DimCustomer c
JOIN rtl.DimCountry k ON k.Country = c.Country
OUTER APPLY (
    SELECT TOP (1) p.Family
    FROM rtl.Line l JOIN rtl.DimProduct p ON p.StockCode = l.StockCode
    WHERE l.CustomerID = c.CustomerID AND l.IsReturn = 0 AND l.ExcludeReason IS NULL
    GROUP BY p.Family ORDER BY SUM(l.Revenue) DESC, p.Family) fav
WHERE c.Segment IN ('At risk, high value', 'At risk');
GO

/* Monthly net sales and a 12-month forecast with an 80% range (feeds the report's forecast chart).
   Uses complete months only (December 2011 ends on the 9th). Two complete trading years (Dec to Nov).
   Forecast = average month of the last 12 x seasonal index for the calendar month x yearly growth,
   applied from the middle of the last 12 months. Range = forecast x (1 +/- 1.28 x the typical miss on past months). */
CREATE OR ALTER VIEW rtl.vForecastMonthly AS
WITH m AS (
    SELECT MonthStart, SUM(Gross - Returns) AS Sales,
           YEAR(MonthStart) + CASE WHEN MONTH(MonthStart) = 12 THEN 1 ELSE 0 END AS TradingYear
    FROM rtl.FactSalesMonth
    WHERE MonthStart < '2011-12-01'
    GROUP BY MonthStart),
lastm AS (SELECT MAX(MonthStart) AS LastMonth FROM m),
season AS (
    SELECT MONTH(MonthStart) AS MonthNo, AVG(Sales) / (SELECT AVG(Sales) FROM m) AS SeasonalIndex
    FROM m GROUP BY MONTH(MonthStart)),
year_avg AS (SELECT TradingYear, AVG(Sales) AS AvgSales FROM m GROUP BY TradingYear),
miss AS (
    SELECT STDEVP(m.Sales / (y.AvgSales * s.SeasonalIndex) - 1) AS TypicalMiss
    FROM m JOIN year_avg y ON y.TradingYear = m.TradingYear JOIN season s ON s.MonthNo = MONTH(m.MonthStart)),
lvl AS (
    SELECT SUM(CASE WHEN m.MonthStart > DATEADD(month, -12, l.LastMonth) THEN m.Sales END) AS Last12,
           SUM(CASE WHEN m.MonthStart <= DATEADD(month, -12, l.LastMonth) THEN m.Sales END) AS Prior12
    FROM m CROSS JOIN lastm l),
ahead AS (SELECT TOP (12) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS h FROM sys.all_objects),
fc AS (
    SELECT DATEADD(month, a.h, l.LastMonth) AS MonthStart,
           v.Last12 / 12.0 * s.SeasonalIndex * POWER(v.Last12 / v.Prior12, (a.h + 5.5) / 12.0) AS Forecast
    FROM ahead a CROSS JOIN lastm l CROSS JOIN lvl v
    JOIN season s ON s.MonthNo = MONTH(DATEADD(month, a.h, l.LastMonth)))
SELECT m.MonthStart AS [Month], CAST(m.Sales AS decimal(14,2)) AS Actual,
       CASE WHEN m.MonthStart = l.LastMonth THEN CAST(m.Sales AS decimal(14,2)) END AS Forecast,
       CAST(NULL AS decimal(14,2)) AS Low, CAST(NULL AS decimal(14,2)) AS High
FROM m CROSS JOIN lastm l
UNION ALL
SELECT f.MonthStart, NULL, CAST(f.Forecast AS decimal(14,2)),
       CAST(f.Forecast * (1 - 1.28 * x.TypicalMiss) AS decimal(14,2)), CAST(f.Forecast * (1 + 1.28 * x.TypicalMiss) AS decimal(14,2))
FROM fc f CROSS JOIN miss x;
GO
