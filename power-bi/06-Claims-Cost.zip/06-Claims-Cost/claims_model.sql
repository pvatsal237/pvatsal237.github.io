/* Harbourview Insurance (fictional) - claims star schema, SQL Server 2019+
   Loads claims.csv and claims_adjusters.csv, builds the dimension and fact tables
   the Power BI model reads, checks the data, and produces the monthly forecast view.
   Change @Folder to the folder that holds the two CSV files. */

SET NOCOUNT ON;
IF SCHEMA_ID('stg') IS NULL EXEC('CREATE SCHEMA stg');
IF SCHEMA_ID('clm') IS NULL EXEC('CREATE SCHEMA clm');
GO

/* ---------- 1. Staging: raw files, loaded as text */
DROP TABLE IF EXISTS stg.Claim, stg.Adjuster;
CREATE TABLE stg.Claim (
    ClaimID varchar(12), ReportDate varchar(10), LossDate varchar(10), CloseDate varchar(10), Line varchar(20), Peril varchar(40),
    Region varchar(40), Channel varchar(20), AdjusterKey varchar(5), CatastropheEvent varchar(40), Litigated varchar(3), SIUReferral varchar(3),
    Outcome varchar(10), Status varchar(10), DaysToClose varchar(10), DailyExpense varchar(20), ExpenseDays varchar(10),
    Incurred varchar(20), LegalCost varchar(20));
CREATE TABLE stg.Adjuster (AdjusterKey varchar(5), Adjuster varchar(60), Team varchar(40));
GO

DECLARE @Folder nvarchar(260) = N'C:\Users\srush\Downloads\Certificates\Portfolio\Data\06-Claims\';
DECLARE @sql nvarchar(max) =
    N'BULK INSERT stg.Claim FROM ''' + @Folder + N'claims.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, CODEPAGE = ''65001'');' +
    N'BULK INSERT stg.Adjuster FROM ''' + @Folder + N'claims_adjusters.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, CODEPAGE = ''65001'');';
EXEC sp_executesql @sql;
GO

/* ---------- 2. Dimensions */
DROP TABLE IF EXISTS clm.FactClaim, clm.DimAdjuster, clm.DimDate;

CREATE TABLE clm.DimAdjuster (
    AdjusterKey    smallint     NOT NULL PRIMARY KEY,
    Adjuster       varchar(60)  NOT NULL,
    Team           varchar(40)  NOT NULL,
    TeamLeadEmail  varchar(120) NOT NULL   -- used by the Team lead security role in Power BI
);
INSERT clm.DimAdjuster
SELECT CAST(AdjusterKey AS smallint), Adjuster, Team,
       CONCAT('lead.', LOWER(REPLACE(Team, ' ', '-')), '@harbourview.example')
FROM stg.Adjuster;

/* Daily date table, Jan 2023 to the last report date */
CREATE TABLE clm.DimDate (
    [Date] date NOT NULL PRIMARY KEY, [Year] smallint NOT NULL, MonthStart date NOT NULL, [Month] varchar(8) NOT NULL);

DECLARE @d date = '2023-01-01', @end date = (SELECT MAX(CAST(ReportDate AS date)) FROM stg.Claim);
WITH n AS (SELECT TOP (DATEDIFF(day, @d, @end) + 1) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS i
           FROM sys.all_objects a CROSS JOIN sys.all_objects b)
INSERT clm.DimDate
SELECT x.[Date], YEAR(x.[Date]), DATEFROMPARTS(YEAR(x.[Date]), MONTH(x.[Date]), 1), FORMAT(x.[Date], 'MMM yyyy')
FROM n CROSS APPLY (SELECT DATEADD(day, n.i, @d) AS [Date]) x;

/* ---------- 3. Fact: one row per claim */
CREATE TABLE clm.FactClaim (
    ClaimID           varchar(12)   NOT NULL PRIMARY KEY,
    ReportDate        date          NOT NULL REFERENCES clm.DimDate ([Date]),
    LossDate          date          NOT NULL,
    CloseDate         date          NULL,
    Line              varchar(20)   NOT NULL CHECK (Line IN ('Auto', 'Home', 'Commercial')),
    Peril             varchar(40)   NOT NULL,
    Region            varchar(40)   NOT NULL,
    Channel           varchar(20)   NOT NULL CHECK (Channel IN ('Mobile app', 'Phone', 'Broker')),
    AdjusterKey       smallint      NOT NULL REFERENCES clm.DimAdjuster (AdjusterKey),
    CatastropheEvent  varchar(40)   NOT NULL,
    Litigated         varchar(3)    NOT NULL,
    SIUReferral       varchar(3)    NOT NULL,
    Outcome           varchar(10)   NOT NULL,
    Status            varchar(10)   NOT NULL CHECK (Status IN ('Open', 'Closed')),
    DaysToClose       int           NULL,
    DailyExpense      decimal(9,2)  NOT NULL,
    ExpenseDays       int           NOT NULL,
    Incurred          decimal(12,2) NOT NULL,
    LegalCost         decimal(12,2) NOT NULL,
    CONSTRAINT CK_FactClaim_Dates CHECK (LossDate <= ReportDate AND (CloseDate IS NULL OR CloseDate >= ReportDate))
);
INSERT clm.FactClaim
SELECT ClaimID, CAST(ReportDate AS date), CAST(LossDate AS date), TRY_CAST(NULLIF(CloseDate, '') AS date), Line, Peril, Region, Channel,
       CAST(AdjusterKey AS smallint), CatastropheEvent, Litigated, SIUReferral, Outcome, Status,
       TRY_CAST(TRY_CAST(NULLIF(DaysToClose, '') AS float) AS int),   -- the file writes whole days as 3.0
       CAST(DailyExpense AS decimal(9,2)), CAST(ExpenseDays AS int), CAST(Incurred AS decimal(12,2)), CAST(LegalCost AS decimal(12,2))
FROM stg.Claim;
GO

/* ---------- 4. Checks: each should return 0 rows */
-- closed claims have a close date and days to close that agree
SELECT ClaimID FROM clm.FactClaim
WHERE Status = 'Closed' AND (CloseDate IS NULL OR DaysToClose <> DATEDIFF(day, ReportDate, CloseDate));
-- open claims have no close date
SELECT ClaimID FROM clm.FactClaim WHERE Status = 'Open' AND CloseDate IS NOT NULL;
-- legal cost only on litigated claims
SELECT ClaimID FROM clm.FactClaim WHERE LegalCost > 0 AND Litigated <> 'Yes';
-- no negative cost
SELECT ClaimID FROM clm.FactClaim WHERE Incurred < 0 OR DailyExpense < 0;
GO

/* ---------- 5. Views the Power BI model reads (business names) */
CREATE OR ALTER VIEW clm.vClaim AS
SELECT ClaimID AS [Claim ID], ReportDate AS [Report Date], CloseDate AS [Close Date], Line, Peril, Region, Channel,
       AdjusterKey AS [Adjuster Key], CatastropheEvent AS [Catastrophe Event], Litigated, SIUReferral AS [SIU Referral],
       Outcome, Status, DaysToClose AS [Days to Close],
       CASE WHEN DaysToClose IS NULL THEN 'Still open' WHEN DaysToClose <= 30 THEN '0-30 days' WHEN DaysToClose <= 60 THEN '31-60 days'
            WHEN DaysToClose <= 90 THEN '61-90 days' WHEN DaysToClose <= 180 THEN '91-180 days' ELSE 'Over 180 days' END AS [Days Band],
       DailyExpense AS [Daily Expense], ExpenseDays AS [Expense Days], Incurred, LegalCost AS [Legal Cost],
       DATEFROMPARTS(YEAR(ReportDate), MONTH(ReportDate), 1) AS [Report Month]
FROM clm.FactClaim;
GO
CREATE OR ALTER VIEW clm.vAdjuster AS
SELECT AdjusterKey AS [Adjuster Key], Adjuster, Team, TeamLeadEmail AS [Team Lead Email] FROM clm.DimAdjuster;
GO

/* ---------- 6. Monthly actual and forecast, 12 months ahead (feeds the report's forecast chart)
   Weather-event claims are left out of the forecast, because a storm is not a repeatable trend.
   Forecast = average month of the last 12 x seasonal index for the calendar month x yearly growth.
   Seasonal index = that calendar month's average over complete years / the average month.
   Growth = last 12 months / the 12 months before, applied from the middle of the last 12 months.
   80% range = forecast x (1 +/- 1.28 x the typical miss of the seasonal pattern on past months). */
CREATE OR ALTER VIEW clm.vForecastMonthly AS
WITH actual AS (
    SELECT d.MonthStart, SUM(f.Incurred) AS Cost
    FROM clm.FactClaim f JOIN clm.DimDate d ON d.[Date] = f.ReportDate
    GROUP BY d.MonthStart),
m AS (
    SELECT d.MonthStart, SUM(f.Incurred) AS Cost
    FROM clm.FactClaim f JOIN clm.DimDate d ON d.[Date] = f.ReportDate
    WHERE f.CatastropheEvent = 'None'
    GROUP BY d.MonthStart),
lastm AS (SELECT MAX(MonthStart) AS LastMonth FROM m),
full_years AS (SELECT m.* FROM m CROSS JOIN lastm WHERE YEAR(m.MonthStart) < YEAR(lastm.LastMonth)),
season AS (
    SELECT MONTH(MonthStart) AS MonthNo, AVG(Cost) / (SELECT AVG(Cost) FROM full_years) AS SeasonalIndex
    FROM full_years GROUP BY MONTH(MonthStart)),
year_avg AS (SELECT YEAR(MonthStart) AS Yr, AVG(Cost) AS AvgCost FROM full_years GROUP BY YEAR(MonthStart)),
miss AS (
    SELECT STDEVP(fy.Cost / (y.AvgCost * s.SeasonalIndex) - 1) AS TypicalMiss
    FROM full_years fy
    JOIN year_avg y ON y.Yr = YEAR(fy.MonthStart)
    JOIN season s ON s.MonthNo = MONTH(fy.MonthStart)),
lvl AS (
    SELECT SUM(CASE WHEN m.MonthStart > DATEADD(month, -12, l.LastMonth) THEN m.Cost END) AS Last12,
           SUM(CASE WHEN m.MonthStart > DATEADD(month, -24, l.LastMonth) AND m.MonthStart <= DATEADD(month, -12, l.LastMonth) THEN m.Cost END) AS Prior12
    FROM m CROSS JOIN lastm l),
ahead AS (SELECT TOP (12) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS h FROM sys.all_objects),
fc AS (
    SELECT DATEADD(month, a.h, l.LastMonth) AS MonthStart,
           v.Last12 / 12.0 * s.SeasonalIndex * POWER(v.Last12 / v.Prior12, (a.h + 5.5) / 12.0) AS Forecast
    FROM ahead a
    CROSS JOIN lastm l
    CROSS JOIN lvl v
    JOIN season s ON s.MonthNo = MONTH(DATEADD(month, a.h, l.LastMonth)))
SELECT a.MonthStart AS [Month], CAST(a.Cost AS decimal(14,2)) AS Actual,
       CASE WHEN a.MonthStart = l.LastMonth THEN CAST(a.Cost AS decimal(14,2)) END AS Forecast,   -- joins the two lines
       CAST(NULL AS decimal(14,2)) AS Low, CAST(NULL AS decimal(14,2)) AS High
FROM actual a CROSS JOIN lastm l
UNION ALL
SELECT f.MonthStart, NULL, CAST(f.Forecast AS decimal(14,2)),
       CAST(f.Forecast * (1 - 1.28 * x.TypicalMiss) AS decimal(14,2)), CAST(f.Forecast * (1 + 1.28 * x.TypicalMiss) AS decimal(14,2))
FROM fc f CROSS JOIN miss x;
GO
